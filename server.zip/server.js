const express = require('express');
const cors = require('cors');
const db = require('./db'); 

const app = express();

// Enable CORS
app.use(cors());


app.get('/', async (req, res) => {
    try {
      const result = await db.query('SELECT * FROM MOCK_DATA where employee_id<=20');
      res.json(result.rows); // Ensure your db.query returns a result with a rows property
    } catch (err) {
      console.error('Database query error:', err); // Improved error logging
      res.status(500).send('Internal Server Error');
    }
  });

// Define the port
const port = 3000;

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

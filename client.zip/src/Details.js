import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Navbar from "./UI-components/Navbar";
import Sidebar from "./UI-components/Sidebar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Details = () => {
  const { id } = useParams(); 
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `https://jsonplaceholder.typicode.com/users/${id}`
        );
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-danger" role="alert">
        Error: {error.message}
      </div>
    );
  }

  return (
    <div>
      <Navbar />
      <div className="container-fluid">
        <div className="row">
          <Sidebar />
          <main className="col-md-9 ms-sm-auto col-lg-10 px-4">
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
              <h1 className="h2">Details for {data.name}</h1>
            </div>
            <div className="card mb-4">
              <div className="card-body">
                <h5 className="card-title">User Details</h5>
                <p className="card-text">
                  <strong>ID:</strong> {data.id}
                </p>
                <p className="card-text">
                  <strong>Name:</strong> {data.name}
                </p>
                <p className="card-text">
                  <strong>Username:</strong> {data.username}
                </p>
                <p className="card-text">
                  <strong>Email:</strong> {data.email}
                </p>
                <p className="card-text">
                  <strong>Phone:</strong> {data.phone}
                </p>
              </div>
              <div className="card-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => window.history.back()}
                >
                  Back
                </button>
              </div>
            </div>
          </main>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default Details;


import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "./UI-components/Navbar";
import Sidebar from "./UI-components/Sidebar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import { Modal, Button, Form } from "react-bootstrap";
import { FaEye, FaEdit } from "react-icons/fa"; // Import icons

const Order = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [formData, setFormData] = useState({});

  const navigate = useNavigate();
  const notify = () => toast("Logout Successfully");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:3000/");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleEditClick = (employee) => {
    setSelectedEmployee(employee);
    setFormData(employee);
    setShowModal(true);
  };

  const handleModalClose = () => {
    setShowModal(false);
    setSelectedEmployee(null);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`http://localhost:3000/employees/${formData.employee_id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to update employee');
      }

      toast.success('Employee updated successfully');
      handleModalClose(); // Close modal after saving changes
    } catch (error) {
      toast.error(`Error: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-danger" role="alert">
        Error: {error.message}
      </div>
    );
  }

  return (
    <div>
      <Navbar />
      <div className="row">
        <Sidebar />
        <div className="container mt-4 col-md-9">
          <h1 className="mb-4">Employee Data</h1>
          {data.length > 0 ? (
            <div className="table-responsive">
              <table className="table table-bordered table-striped table-hover">
                <thead className="table-dark">
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>August PR</th>
                    <th>September PR</th>
                    <th>October PR</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((employee) => (
                    <tr key={employee.employee_id}>
                      <td>{employee.employee_id}</td>
                      <td>{employee.employee_name}</td>
                      <td>{employee.department}</td>
                      <td>{employee.aug_pr}</td>
                      <td>{employee.sep_pr}</td>
                      <td>{employee.oct_pr}</td>

                      <td className="d-flex justify-content-around">
                        <Link to={`/details/${employee.employee_id}`} className="btn btn-link text-info">
                          <FaEye size={20} />
                        </Link>

                        <Button
                          variant="link"
                          className="text-info"
                          onClick={() => handleEditClick(employee)}
                        >
                          <FaEdit size={20} />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p>No data available</p>
          )}
        </div>
      </div>

      <Modal show={showModal} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Employee</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedEmployee && (
            <Form onSubmit={handleFormSubmit}>
              <Form.Group controlId="formEmployeeName">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  name="employee_name"
                  value={formData.employee_name || ""}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Form.Group controlId="formEmployeeDepartment">
                <Form.Label>Department</Form.Label>
                <Form.Control
                  type="text"
                  name="employee_department"
                  value={formData.employee_department || ""}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Form.Group controlId="formAugustPR">
                <Form.Label>August PR</Form.Label>
                <Form.Control
                  type="number"
                  name="aug_pr"
                  value={formData.aug_pr || ""}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Form.Group controlId="formSeptemberPR">
                <Form.Label>September PR</Form.Label>
                <Form.Control
                  type="number"
                  name="sep_pr"
                  value={formData.sep_pr || ""}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Form.Group controlId="formOctoberPR">
                <Form.Label>October PR</Form.Label>
                <Form.Control
                  type="number"
                  name="oct_pr"
                  value={formData.oct_pr || ""}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Button variant="primary" type="submit">
                Save Changes
              </Button>
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <ToastContainer />
    </div>
  );
};

export default Order;

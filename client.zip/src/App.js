import React from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
// import Layout from './Layout';
import Login from './login'
import Home from './Home'
import Order from './Order'
import Details from './Details';


const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Routes>
            <Route path='/' element={<Login/>}/>
            <Route path='/Home' element={<Home/>}/>
            <Route path='/Order' element={<Order/>}/>
            <Route path='/details/:id' element={<Details />} />

        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Cookies from "js-cookie";
import Img from "./assets/avathar.png";
import Logo from "./assets/logo.png";
import Card from "./assets/simplePay_credit_card.PNG";
import Navbar from "./UI-components/Navbar";
import Sidebar from "./UI-components/Sidebar";
import { Bar } from "react-chartjs-2";
// import { Line } from "react-chartjs-2";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

const Home = () => {
  const [userEmail, setUserEmail] = useState("");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const notify = () => toast("Logout Successfully");

  // useEffect(() => {
  //   const email = Cookies.get("userEmail");
  //   if (email) {
  //     const parts = email.split("@");
  //     setUserEmail(parts[0]);
  //   } else {
  //     navigate("/");
  //   }
  // }, [navigate]);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:3000/");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const logout = (e) => {
    e.preventDefault();
    notify();
    setTimeout(() => {
      //Cookies.remove("userEmail");
      navigate("/");
    }, 2000);
  };

  const getRandomColor = () => {
    const letters = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  const chartData = {
    labels: data.map((employee) => employee.employee_name),
    datasets: [
      {
        label: "August",
        data: data.map((employee) => employee.aug_pr),
        backgroundColor: "rgba(255, 99, 132, 0.2)",
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 1,
      },
      {
        label: "September",
        data: data.map((employee) => employee.sep_pr),
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1,
      },
      {
        label: "October",
        data: data.map((employee) => employee.oct_pr),
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
      },
    ],
  };

  const calculateTotals = (data) => {
    if (!data.length) return { total: 0, aug: 0, sep: 0, oct: 0 };

    const total = data.length;
    const aug = data.reduce((acc, employee) => acc + (employee.aug_pr || 0), 0);
    const sep = data.reduce((acc, employee) => acc + (employee.sep_pr || 0), 0);
    const oct = data.reduce((acc, employee) => acc + (employee.oct_pr || 0), 0);

    return { total, aug, sep, oct };
  };

  const { total, aug, sep, oct } = calculateTotals(data);

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            return `${context.dataset.label}: ${context.raw}`;
          },
        },
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Employees",
        },
        ticks: {
          autoSkip: false,
        },
      },
      y: {
        title: {
          display: true,
          text: "Performance Rating",
        },
      },
    },
  };
  return (
    <div>
      <ToastContainer />
      <Navbar />

      <div className="container-fluid">
        <div className="row">
          <Sidebar />

          <main className="col-md-9 ms-sm-auto col-lg-10 px-md-2">
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
              <h1 className="h2">Dashboard</h1>
            </div>

            <div className="row">
              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body">
                    <h5 className="card-title">
                      <i className="fas fa-users"></i> Total Employees
                    </h5>
                    <p className="card-text">{total}</p>
                  </div>
                </div>
              </div>

              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body text-center">
                    <h5 className="card-title">
                      <i className="fas fa-trophy"></i> Top Employee
                    </h5>
                    {data.length > 0 && (
                      <>
                        <h6 className="card-subtitle mb-2 text-muted">
                          {
                            data.reduce(
                              (max, emp) =>
                                emp.aug_pr > max.aug_pr ? emp : max,
                              data[0]
                            ).employee_name
                          }
                        </h6>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body text-center">
                    <h5 className="card-title">
                      <i className="fas fa-trophy"></i> Top Employee (September)
                    </h5>
                    {data.length > 0 && (
                      <>
                        <h6 className="card-subtitle mb-2 text-muted">
                          {
                            data.reduce(
                              (max, emp) =>
                                emp.sep_pr > max.sep_pr ? emp : max,
                              data[0]
                            ).employee_name
                          }
                        </h6>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body">
                    <h5 className="card-title">
                      <i className="fas fa-calendar-day"></i> September
                      Presentations
                    </h5>
                    <p className="card-text">
                      {data.reduce(
                        (acc, employee) => acc + (employee.sep_pr || 0),
                        0
                      )}
                    </p>
                  </div>
                </div>
              </div>

              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body">
                    <h5 className="card-title">
                      <i className="fas fa-calendar-day"></i> Total
                      Presentations
                    </h5>
                    <p className="card-text">
                      {data.reduce(
                        (acc, employee) =>
                          acc +
                          (employee.aug_pr || 0) +
                          (employee.sep_pr || 0) +
                          (employee.oct_pr || 0),
                        0
                      )}
                    </p>
                  </div>
                </div>
              </div>

              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body">
                    <h5 className="card-title">
                      <i className="fas fa-calendar-day"></i> August Presented
                    </h5>
                    <p className="card-text">{aug}</p>
                  </div>
                </div>
              </div>
              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body">
                    <h5 className="card-title">
                      <i className="fas fa-calendar-day"></i> September
                      Presented
                    </h5>
                    <p className="card-text">{sep}</p>
                  </div>
                </div>
              </div>
              <div className="col-lg-3">
                <div className="card shadow">
                  <div className="card-body">
                    <h5 className="card-title">
                      <i className="fas fa-calendar-day"></i> October Presented
                    </h5>
                    <p className="card-text">{oct}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-6">
                <div className="p-grid d-flex">
                  <div className="col-md-6">
                    <div className="card">
                      <div className="card-body">
                        <div className="pb-3 mb-3 border-bottom">
                          <h1 className="h4">OmGoing Projects</h1>
                        </div>

                        <h1 className="h5">Project 1</h1>
                        <div className="progress mt-4">
                          <div
                            className="progress-bar bg-primary"
                            role="progressbar"
                            style={{ width: "25%" }}
                            aria-valuenow="25"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          >
                            25%
                          </div>
                        </div>
                        <hr />
                        <h1 className="h5">Project 2</h1>
                        <div className="progress mt-3">
                          <div
                            className="progress-bar bg-success"
                            role="progressbar"
                            style={{ width: "40%" }}
                            aria-valuenow="40"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          >
                            40%
                          </div>
                        </div>
                        <hr />
                        <h1 className="h5">Project 3</h1>
                        <div className="progress mt-3">
                          <div
                            className="progress-bar bg-success"
                            role="progressbar"
                            style={{ width: "73%" }}
                            aria-valuenow="73"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          >
                            73%
                          </div>
                        </div>
                        <hr />
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="card">
                      <div className="card-body">
                        <div className="pb-2 mb-3 border-bottom">
                          <h1 className="h4">Transaction</h1>
                        </div>
                        <table className="table table-striped">
                          <thead>
                            <tr>
                              <th scope="col">Date</th>
                              <th scope="col">Description</th>
                              <th scope="col">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>2024-07-20</td>
                              <td>Payment from Client A</td>
                              <td>$500.00</td>
                            </tr>
                            <tr>
                              <td>2024-07-19</td>
                              <td>Withdrawal - ATM</td>
                              <td>-$100.00</td>
                            </tr>
                            <tr>
                              <td>2024-07-18</td>
                              <td>Deposit - Salary</td>
                              <td>$3,000.00</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <br></br>
                

                 
                </div>
                <div className="p-grid">
                  <div class="card m-2">
                    <div class="card-header">Advanced Settings</div>
                    <div class="card-body">
                      <h5 class="card-title">Track Attendance Via Table</h5>
                      <p class="card-text">
                        With supporting text below as a natural lead-in to
                        additional content.
                      </p>
                      <a href="/Order" class="btn btn-primary">
                        Table
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                {/* <div className="row mt-4">
                  <div className="col-md-12">
                    <div className="card">
                      <div className="card-body">
                        <h1 className="h4">Employee Performance</h1>
                        <Bar
                          data={chartData}
                          options={{
                            responsive: true,
                            plugins: {
                              legend: {
                                position: "top",
                              },
                              tooltip: {
                                callbacks: {
                                  label: (context) => {
                                    return `${context.dataset.label}: ${context.raw}`;
                                  },
                                },
                              },
                            },
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div> */}

                <div className="row mt-4">
                  <div className="col-md-12">
                    <div className="card">
                      <div className="card-body">
                        <h1 className="h4">Employee Performance</h1>
                        <Bar data={chartData} options={chartOptions} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default Home;

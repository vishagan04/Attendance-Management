
// Sidebar.js
import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import './sidebar.css';

const Sidebar = () => {
  const navigate = useNavigate();
  const notify = () => toast("Logout Successfully");

  const logout = (e) => {
    e.preventDefault();
    notify();
    setTimeout(() => {
      // Cookies.remove("userEmail");
      navigate("/");
    }, 2000);
  };

  return (
    <nav id="sidebar" className="col-md-3 min-vh-90 col-lg-2 d-md-block bg-light sidebar">
      <div className="position-fixed min-vh-100  border-end ">
        <ul className="nav flex-column">
          <li className="nav-item">
            <NavLink
              className="nav-link text-dark"
              to="/Home"
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                color: isActive ? '#007bff' : 'inherit', // Bootstrap primary color for active
              })}
            >
              <i className="fas fa-tachometer-alt"></i> Dashboard
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink
              className="nav-link text-dark"
              to="/Order"
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                color: isActive ? '#007bff' : 'inherit', // Bootstrap primary color for active
              })}
            >
              <i className="fas fa-shopping-cart"></i> Attendance Sheet
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink
              className="nav-link text-dark"
              to="/Products"
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                color: isActive ? '#007bff' : 'inherit', // Bootstrap primary color for active
              })}
            >
              <i className="fas fa-box"></i> Products
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink
              className="nav-link text-dark"
              to="/Planning"
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                color: isActive ? '#007bff' : 'inherit', // Bootstrap primary color for active
              })}
            >
              <i className="fas fa-calendar-alt"></i> Planning
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink
              className="nav-link text-dark"
              to="/Settings"
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                color: isActive ? '#007bff' : 'inherit', // Bootstrap primary color for active
              })}
            >
              <i className="fas fa-cog"></i> Settings
            </NavLink>
          </li>
        </ul>
        <hr />
        <ul className="nav flex-column">
          <li className="nav-item">
            <NavLink
              className="nav-link text-dark"
              to="/Help"
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                color: isActive ? '#007bff' : 'inherit', // Bootstrap primary color for active
              })}
            >
              <i className="fas fa-question-circle"></i> Help
            </NavLink>
          </li>
          <li className="nav-item">
            <a className="nav-link text-dark" href="#" onClick={logout}>
              <i className="fas fa-sign-out-alt"></i> Logout
            </a>
          </li>
        </ul>
        <div
          className="card d-flex justify-content-center align-items-center  my-5"
          style={{ marginTop: "10px", top:"300px", marginRight: "15px" }}
        >
          <div className="card-title">
            <h1 className="h4">Found a Bug?</h1>
          </div>
          <div className="card-body">
            <p>Contact us for support</p>
            <button className="btn btn-danger col-md-12" type="submit">
              Report
            </button>
          </div>
        </div>
      </div>
      <ToastContainer />
    </nav>
  );
};

export default Sidebar;
